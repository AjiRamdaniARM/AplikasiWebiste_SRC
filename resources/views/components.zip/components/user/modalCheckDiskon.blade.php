{{-- open modal berhasil --}}
<div id="open-modal-berhasil" class="modal-window">
    <div>
        <a class="modal-close" href="#">Close</a>
        <img src="{{ asset('assets/banner-diskon.jpg') }}" alt="">
    </div>
</div>
{{-- akhir open modal --}}

{{-- open-modal failed --}}
<div id="open-modal" class="modal-window">
    <div>
        <a class="modal-close" href="#">Close</a>
        <img src="{{ asset('assets/banner-failed.jpg') }}" alt="">
    </div>
</div>
{{-- akhir open modal failed --}}


{{-- open-modal failed --}}
<div id="open-modal-nothing" class="modal-window">
    <div>
        <a class="modal-close" href="#">Close</a>
        <img src="{{ asset('assets/no.kode.jpg') }}" alt="">
    </div>
</div>
{{-- akhir open modal failed --}}
